<?php get_header();?>

    <div class="container">
        <h1 class="mt-3">Categories: <?php single_cat_title();?></h1>
        <?php if (have_posts()) : while(have_posts()) : the_post();?>
        <div class="card m-5">
            <div class="card-body">
                <h2 class="card-title"><?php the_title();?></h2>
                <p class="card-subtitle mb-2 text-muted">
                    <?php 
                        $fname = get_the_author_meta('first_name');
                        $lname = get_the_author_meta('last_name');
                    ?>
                    <p>Posted by <?php echo $fname; ?> <?php echo $lname; ?></p>
                </p>
                <hr>
                <div class="row">
                    <div class="col-4">
                        <?php if(has_post_thumbnail()):?>
                            <img src="<?php the_post_thumbnail_url('blog-small')?>" alt="<?php the_title();?>" class="img-fluid" width="300px">
                        <?php endif;?>
                    </div>
                    <div class="col-7">
                        <?php the_excerpt();?>
                        
                        <?php echo get_the_date('d/m/Y h:i:s')?>
                        
                        <div class="mt-1">
                            <a href="<?php the_permalink();?>" class="btn btn-dark">Read more</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endwhile; endif;?>
        <?php previous_posts_link();?>
        <?php next_posts_link();?>
    </div>

<?php get_footer();?>