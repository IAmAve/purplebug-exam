$(window).on('load',function() {
  $('.flexslider').flexslider({
    animation: "slide",
    animationLoop: true,
    
  });
});