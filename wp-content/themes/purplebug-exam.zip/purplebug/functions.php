<?php 

function load_stylesheets(){

    wp_register_style('bootstrap', get_template_directory_uri() . '/css/bootstrap.min.css',
    array(), false, 'all');
    wp_enqueue_style('bootstrap');

    wp_register_style('flexslider', get_template_directory_uri() . '/css/flexslider.css',
    array(), false, 'all');
    wp_enqueue_style('flexslider');


    wp_register_style('mystyle', get_template_directory_uri() . '/style.css',
    array(), false, 'all');
    wp_enqueue_style('mystyle');
}
add_action('wp_enqueue_scripts', 'load_stylesheets');

function jquery(){
    wp_deregister_script('jquery');
    wp_enqueue_script('jquery', get_template_directory_uri() . '/js/jquery.min.js', '', 1, true);
}
add_action('wp_enqueue_scripts', 'jquery');


function bootstrapjs(){

    wp_register_script('bootstrapjs', get_template_directory_uri() . '/js/bootstrap.min.js','', 1, true);
    wp_enqueue_script('bootstrapjs');

}
add_action('wp_enqueue_scripts', 'bootstrapjs');

function loadjs(){

    wp_register_script('myjs', get_template_directory_uri() . '/js/main.js','', 1, true);
    wp_enqueue_script('myjs');

    wp_register_script('flexslider', get_template_directory_uri() . '/js/jquery.flexslider-min.js','', 1, true);
    wp_enqueue_script('flexslider');

}
add_action('wp_enqueue_scripts', 'loadjs');


add_theme_support('menus');
add_theme_support('post-thumbnails');
add_theme_support('widgets');

register_nav_menus(
    array(
        'top-menu'=> __('Top Menu', 'theme'),
        'footer-menu'=> __('Footer Menu', 'theme'),
    )
    );

add_image_size('blog-small', 300, 300, true);
add_image_size('blog-large', 800, 800, true);
add_image_size('slider', 1200, 700, true);


function sidebars(){
    register_sidebar(
        array(
            'name' => 'Page Sidebar',
            'id' => 'page-sidebar',
            'before_title' => '<h4 class="widget-title">',
            'after_title' => '</h4>'
            )
        );

        register_sidebar(
            array(
                'name' => 'Blog Sidebar',
                'id' => 'page-sidebar',
                'before_title' => '<h4 class="widget-title">',
                'after_title' => '</h4>'
            )
            );

}

/**
 * Register Custom Navigation Walker
 */
function register_navwalker(){
	require_once get_template_directory() . '/class-wp-bootstrap-navwalker.php';
}
add_action( 'after_setup_theme', 'register_navwalker' );

?>