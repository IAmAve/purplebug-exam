<?php get_header();?>
<!--Front Page Carousel-->
    <div class="container-fluid">
        <?php if( have_rows('slides')):?>
            <div class="flexslider">
                <ul class="slides">
                    <?php while( have_rows('slides')): the_row();
                        $image = get_sub_field('image');
                        $imageurl = $image['sizes']['slider'];
                    ?>

                    <li >
                        <img src="<?php echo $imageurl;?>" alt="<?php echo $title;?>">
                    </li>
                    <?php endwhile;?>
                </ul>
            </div>  
        <?php endif;?>
    </div>
<!--Front Page Content-->
    <div class="row">
        <div class="col-8">
        <?php if(have_posts()) : while(have_posts()) : the_post();?>
            <?php the_content()?>
        <?php endwhile; else: endif;?>
        </div>
        <div class="col-4">
            <?php 
                $args = array(
                    'post_type' => 'post',
                    'posts_per_page' => -1
                );
                $_posts =  new WP_Query($args);
            ?>
            <?php while($_posts->have_posts()): $_posts->the_post();?>
                <div class="container">
                    <h1><?php the_title();?></h1>
                    <?php the_excerpt();?>
                </div>
            <?php endwhile;?>
        </div>
    </div>

<?php get_footer();?>